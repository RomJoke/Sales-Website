<?php
session_start();
include('K/connect.php');

// Kiểm tra người dùng đã đăng nhập chưa
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Lấy thông tin người dùng từ cơ sở dữ liệu
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = $user_id"; // Thay 'users' bằng tên bảng của bạn
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

// Cập nhật thông tin khi người dùng gửi form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Cập nhật email
    if (!empty($_POST['email']) && !empty($_POST['current_password'])) {
        $email = $_POST['email'];
        $current_password = $_POST['current_password'];

        // Kiểm tra mật khẩu hiện tại
        if (password_verify($current_password, $user['password'])) {
            // Kiểm tra xem email mới có trùng với email đã tồn tại không
            $email_check_sql = "SELECT * FROM users WHERE email = '$email' AND id != $user_id"; // Kiểm tra email trùng
            $email_check_result = mysqli_query($conn, $email_check_sql);
            
            if (mysqli_num_rows($email_check_result) == 0) { // Nếu không có email nào trùng
                // Cập nhật email vào cơ sở dữ liệu
                $update_email_sql = "UPDATE users SET email='$email' WHERE id=$user_id"; // Thay 'users' bằng tên bảng của bạn
                if (mysqli_query($conn, $update_email_sql)) {
                    echo "<script>alert('Cập nhật email thành công!');</script>";
                } else {
                    echo "Có lỗi: " . mysqli_error($conn);
                }
            } else {
                echo "<script>alert('Email đã tồn tại! Vui lòng nhập email khác.');</script>";
            }
        } else {
            echo "<script>alert('Mật khẩu hiện tại không chính xác!');</script>";
        }
    }

    // Cập nhật mật khẩu
    if (!empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        // Kiểm tra mật khẩu mới và xác nhận mật khẩu
        if ($new_password === $confirm_password) {
            // Mã hóa mật khẩu mới
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            // Cập nhật mật khẩu vào cơ sở dữ liệu
            $update_password_sql = "UPDATE users SET password='$hashed_password' WHERE id=$user_id"; // Thay 'users' bằng tên bảng của bạn
            if (mysqli_query($conn, $update_password_sql)) {
                // Xóa phiên người dùng
                session_destroy();
                echo "<script>alert('Cập nhật mật khẩu thành công! Bạn sẽ được chuyển đến trang đăng nhập.'); window.location='login.php';</script>";
            } else {
                echo "Có lỗi: " . mysqli_error($conn);
            }
        } else {
            echo "<script>alert('Mật khẩu mới không khớp với xác nhận!');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Chỉnh sửa Hồ sơ</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Chỉnh sửa Hồ sơ</h2>
        <form method="POST">
            <div class="form-group">
                <label for="username">Tên người dùng:</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="current_password">Mật khẩu hiện tại:</label>
                <input type="password" class="form-control" id="current_password" name="current_password" required>
            </div>

            <h3>Cập nhật Mật khẩu</h3>
            <div class="form-group">
                <label for="new_password">Mật khẩu mới:</label>
                <input type="password" class="form-control" id="new_password" name="new_password">
            </div>
            <div class="form-group">
                <label for="confirm_password">Xác nhận mật khẩu mới:</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
            </div>

            <button type="submit" class="btn btn-primary">Cập nhật</button>
            <a href="profile.php" class="btn btn-default">Hủy</a>
        </form>
    </div>
</body>
</html>
