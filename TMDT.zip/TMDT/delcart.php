<?php
session_start();
include('K/connect.php'); // Kết nối với cơ sở dữ liệu

// Kiểm tra người dùng đã đăng nhập chưa
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['remove'])) {
    $user_id = $_SESSION['user_id'];
    $product_id = $_GET['remove'];

    // Xóa sản phẩm khỏi giỏ hàng
    $sql = "DELETE FROM cart WHERE user_id = $user_id AND product_id = $product_id";
    $res = mysqli_query($conn, $sql);

    if ($res) {
        // Chuyển hướng trở lại trang giỏ hàng
        header("Location: cart.php");
        exit;
    } else {
        echo "Có lỗi xảy ra trong quá trình xóa sản phẩm.";
    }
} else {
    echo "Không có sản phẩm nào được chọn để xóa.";
}
?>
