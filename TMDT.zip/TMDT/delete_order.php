<?php
include('K/connect.php');

if (isset($_GET['id'])) {
    $order_id = $_GET['id'];

    // Xóa dữ liệu liên quan trong orderitems
    $sql_delete_items = "DELETE FROM orderitems WHERE order_id = ?";
    $stmt_items = $conn->prepare($sql_delete_items);
    $stmt_items->bind_param("i", $order_id);
    $stmt_items->execute();

    // Xóa đơn hàng
    $sql_delete_order = "DELETE FROM orders WHERE id = ?";
    $stmt_order = $conn->prepare($sql_delete_order);
    $stmt_order->bind_param("i", $order_id);

    if ($stmt_order->execute()) {
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

