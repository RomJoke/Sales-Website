<?php
session_start();
include('C:\xampp\htdocs\website\TMDT\K\connect.php');
include('C:\xampp\htdocs\website\TMDT\template\header.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $u = $_POST['username'];
    $p = $_POST['password']; // Lưu mật khẩu chưa mã hóa để kiểm tra
    $repassword = $_POST['repassword']; // Lưu mật khẩu xác nhận
    $e = $_POST['email'];
    $type = $_POST['type']; // Lấy quyền người dùng (admin hoặc member)

    // Kiểm tra mật khẩu và xác nhận mật khẩu có giống nhau không
    if ($p !== $repassword) {
        $mess = "Mật khẩu và mật khẩu xác nhận không giống nhau.";
    } else {
        // Sử dụng prepared statements để tránh SQL Injection
        $sql = "SELECT * FROM users WHERE username = ? OR email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $u, $e);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            $mess = "Username or email already exists";
        } else {
            // Mã hóa mật khẩu
            $p = password_hash($p, PASSWORD_DEFAULT); 

            // Thêm người dùng mới với quyền type (admin hoặc member)
            $sql = "INSERT INTO users (username, password, email, type) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $u, $p, $e, $type);
            $res = $stmt->execute();

            if ($res) {
                $mess = "Đăng ký thành công";
            } else {
                $mess = "Đăng ký thất bại";
            }
        }
    }
}
?>

<div class="container">
    <div style="width: 50%; margin: 0 auto;">
        <h1>Đăng ký tài khoản</h1>
        <form action="" method="POST" onsubmit="return validatePassword()">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" placeholder="Enter Username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" placeholder="Enter email" name="email" required>
            </div>

            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" placeholder="Enter password" name="password" id="password" required>
            </div>
            <div class="form-group">
                <label for="pwd">Repassword:</label>
                <input type="password" class="form-control" placeholder="Enter Repassword" name="repassword" id="repassword" required>
                <span id="error-message" class="error" style="color: red;"></span><br><br>
                <?php
                if (isset($mess) && $mess != "") {
                    ?>
                    <div class="alert <?php echo strpos($mess, 'successful') !== false ? 'alert-success' : 'alert-danger'; ?>">
                        <strong>Info!</strong> <?php echo $mess; ?>.
                    </div>
                    <?php
                }
                ?>
            </div>

            <!-- Thêm lựa chọn quyền user -->
            <div class="form-group">
                <label for="type">Role:</label>
                <select class="form-control" name="type" required>
                    <option value="member">Member</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <div style="margin: 0 auto;">
                <button type="submit" class="btn btn-primary">Register</button> 
                <a href="login.php" class="btn btn-info">Login</a>
            </div>
        </form>
    </div>
</div>

<script>
function validatePassword() {
    var password = document.getElementById("password").value;
    var repassword = document.getElementById("repassword").value;   

    var message = document.getElementById("error-message");   

    if (password === repassword) {
        message.textContent = ""; // Clear the error message
        return true; // Allow form submission
    } else {
        message.textContent = "Mật khẩu không khớp!"; // Show error message
        return false; // Prevent form submission
    }
}
</script>

<?php
include('C:\xampp\htdocs\website\TMDT\template\footer.php');
?>
