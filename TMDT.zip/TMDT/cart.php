<?php
session_start();
require 'K/connect.php';
include 'template/header.php';


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT c.product_id, c.quantity, p.title, p.price 
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = $user_id";

$res = mysqli_query($conn, $sql);

?>
<div class="container">
    <h1>View cart</h1>
    <div class="row">
        <div class="col-md-12">
            <?php
            // Kiểm tra nếu giỏ hàng có hàng
            if ($res->num_rows > 0) {
            ?>
                <form method="POST" action="checkout.php">
                    <table class="table" style="width:90%" align="center">
                        <tr>
                            <th>S.Number</th>
                            <th>Check</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Subtotal</th>
                            <th>Action</th>
                        </tr>
                        <?php
                        $total_price = 0;
                        $i = 1;
                        while ($row = $res->fetch_assoc()) {
                            $product_name = $row['title'];
                            $product_id = $row['product_id'];
                            $quantity = $row['quantity'];
                            $price = $row['price'];
                            $subtotal = $price * $quantity;
                            $total_price += $subtotal;

                        ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td>
                                    <!-- <input type="checkbox" class="item-check" value="<?php echo $product_id; ?>"> -->
                                    <input type="checkbox" name="selected_items[]" value="<?php echo $product_id; ?>|<?php echo $product_name; ?>|<?php echo $quantity; ?>|<?php echo $price; ?>">
                                </td>
                                <td><?php echo $product_name; ?></td>
                                <td><?php echo $quantity; ?></td>
                                <td><?php echo number_format($price, 2) . " VND"; ?></td>
                                <td><?php echo number_format($subtotal, 2) . " VND"; ?></td>
                                <td><a href="delcart.php?remove=<?php echo $row['product_id']; ?>">Remove</a></td>
                            </tr>
                        <?php
                            $i++;
                        }
                        ?>
                        <tr>
                            <th>Total Price</th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th><?php echo number_format($total_price, 2) . " VND"; ?></th>
                            <!-- <th><a href="checkout.php" class="btn btn-info">Checkout</a></th> -->
                            <th><input type="submit" value="Checkout" class="btn btn-primary"></th>
                        </tr>
                    </table>
                </form>
            <?php
            } else {
                echo "<div class='alert alert-danger'>
          <strong>Bạn chưa có sản phẩm nào trong giỏ</strong>
          </div>";
            }
            ?>
        </div>
    </div>
</div>
<?php
$conn->close();
include 'template/footer.php';
?>