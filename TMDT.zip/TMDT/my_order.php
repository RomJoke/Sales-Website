<?php
session_start();
require 'K/connect.php';
include 'template/header.php';
include 'template/nav.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT o.id AS order_id, DATE_FORMAT(o.timestamp, '%d-%m-%Y %H:%i:%s') AS order_date, 
        o.orderstatus AS status, o.payment_status, o.totalprice AS total_price, o.paymentmode AS payment_method
        FROM orders o
        WHERE o.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đơn hàng của tôi</title>
    <style>
        .btn-success,
        .btn-danger {
            padding: 5px 10px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
        }

        .btn-success {
            background-color: #28a745;
            color: white;
        }

        .btn-success:hover {
            background-color: #218838;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .alert {
            margin: 10px 0;
            padding: 10px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
    </style>
    <script>
        function cancelOrder(orderId) {
            if (confirm("Bạn có chắc chắn muốn hủy đơn hàng này không?")) {
                window.location.href = 'cancel-order.php?order_id=' + orderId;
            }
        }
    </script>
</head>

<body>

    <div class="container">
        <h1 class="text-center text-primary mt-4">Đơn hàng của tôi</h1>
        <?php
        if (isset($_GET['tx']) && !empty($_GET['tx'])) {
            $txn_id = $_GET['tx'];

            // Gửi yêu cầu xác minh đến PayPal
            $req = 'cmd=_notify-synch&tx=' . $txn_id . '&at=<YOUR_PAYPAL_PDT_TOKEN>';
            $ch = curl_init('https://www.sandbox.paypal.com/cgi-bin/webscr');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
            $res = curl_exec($ch);
            curl_close($ch);

            if (strpos($res, "SUCCESS") === 0) {
                // Giao dịch thành công
                $order_id = $_GET['order_id']; // custom order ID
                $sql = "UPDATE orders SET payment_status = 'Completed', paymentmode = 'PayPal' WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('i', $order_id);
                $stmt->execute();
                $stmt->close();
                echo "Thanh toán thành công!";
            } else {
                echo "Thanh toán thất bại!";
            }
        }
        ?>

        <!-- Thông báo kết quả hủy đơn hàng -->
        <?php
        if (isset($_GET['status'])) {
            if ($_GET['status'] === 'cancel_success') {
                echo "<div class='alert alert-success'>Đơn hàng đã được hủy thành công!</div>";
            } elseif ($_GET['status'] === 'cancel_failed') {
                echo "<div class='alert alert-danger'>Không thể hủy đơn hàng. Vui lòng thử lại.</div>";
            }
        }
        ?>

        <!-- Bảng hiển thị đơn hàng -->
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ngày</th>
                        <th>Trạng thái</th>
                        <th>Thanh toán</th>
                        <th>Tổng</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['order_id']) ?></td>
                                <td><?= htmlspecialchars($row['order_date']) ?></td>
                                <td class="<?= $row['status'] === 'Order placed' ? 'text-primary' : 'text-success' ?>">
                                    <?= htmlspecialchars($row['status']) ?>
                                </td>
                                <td><?= htmlspecialchars($row['payment_method']) ?></td>
                                <td><?= htmlspecialchars($row['total_price']) ?> USD</td>
                                <td> <?= htmlspecialchars($row['payment_status']) ?></td>
                                <td>
                                    <a href="view-order.php?order_id=<?= $row['order_id'] ?>" class="btn btn-success">Xem</a>
                                    <button class="btn btn-danger" onclick="cancelOrder(<?= $row['order_id'] ?>)">Hủy</button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">Bạn chưa có đơn hàng nào!</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php
$stmt->close();
$conn->close();
include 'template/footer.php';
?>