<?php
include('K/connect.php');

if (isset($_GET['id'])) {
    $order_id = $_GET['id'];

    // Lấy dữ liệu đơn hàng
    $sql = "SELECT * FROM orders WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $order = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Cập nhật dữ liệu đơn hàng
    $totalprice = $_POST['totalprice'];
    $orderstatus = $_POST['orderstatus'];

    $sql = "UPDATE orders SET totalprice = ?, orderstatus = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("dsi", $totalprice, $orderstatus, $order_id);

    if ($stmt->execute()) {
        header("Location: admin_dashboard.php?message=Order updated successfully");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        h1 {
            font-size: 1.5em;
            margin-bottom: 20px;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 1em;
        }

        button:hover {
            background-color: #218838;
        }

        .message {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Order #<?php echo $order['id']; ?></h1>
        <form method="POST">
            <label for="totalprice">Total Price</label>
            <input type="number" step="0.01" name="totalprice" value="<?php echo $order['totalprice']; ?>" required>
            
            <label for="orderstatus">Order Status</label>
            <select name="orderstatus">
                <option value="Pending" <?php echo $order['orderstatus'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="Completed" <?php echo $order['orderstatus'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                <option value="Shipped" <?php echo $order['orderstatus'] == 'Shipped' ? 'selected' : ''; ?>>Shipped</option>
            </select>
            
            <button type="submit">Save Changes</button>
        </form>
    </div>
</body>
</html>
