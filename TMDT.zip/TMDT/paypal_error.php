<?php
session_start();
require 'K/connect.php';

if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];

    // Cập nhật trạng thái đơn hàng thành "Cancelled"
    $sql = "UPDATE orders SET orderstatus = 'Cancelled', payment_status = 'Failed' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    if ($stmt->execute()) {
        $message = "Đơn hàng của bạn đã bị hủy thành công.";
    } else {
        $message = "Đã xảy ra lỗi khi hủy đơn hàng. Vui lòng thử lại.";
    }
    $stmt->close();
} else {
    $message = "Không tìm thấy thông tin đơn hàng.";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh toán thất bại</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background-color: #f8f9fa;
        }
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        h1 {
            color: #dc3545;
        }
        p {
            font-size: 16px;
            margin: 15px 0;
        }
        a {
            text-decoration: none;
            color: white;
            background-color: #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
        }
        a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thanh toán thất bại</h1>
        <p><?= htmlspecialchars($message); ?></p>
        <p>Nếu có bất kỳ vấn đề gì, hãy liên hệ với bộ phận hỗ trợ khách hàng của chúng tôi.</p>
        <a href="cart.php">Quay lại giỏ hàng</a>
        <a href="checkout.php" style="margin-left: 15px;">Thử lại thanh toán</a>
    </div>
</body>
</html>
