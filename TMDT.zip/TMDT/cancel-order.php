<?php
session_start();
require 'K/connect.php';

if (!isset($_GET['order_id']) || !isset($_SESSION['user_id'])) {
    header('Location: my_order.php');
    exit();
}

$order_id = intval($_GET['order_id']);
$user_id = intval($_SESSION['user_id']);

// Kiểm tra đơn hàng có thuộc về user hiện tại không
$sql_check = "SELECT id FROM orders WHERE id = ? AND user_id = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param('ii', $order_id, $user_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows === 0) {
    header('Location: my_order.php?status=cancel_failed');
    exit();
}

// Xóa các mục trong bảng orderitems liên quan đến order_id
$sql_delete_items = "DELETE FROM orderitems WHERE order_id = ?";
$stmt_delete_items = $conn->prepare($sql_delete_items);
$stmt_delete_items->bind_param('i', $order_id);
$stmt_delete_items->execute();

// Xóa đơn hàng trong bảng orders
$sql_delete_order = "DELETE FROM orders WHERE id = ? AND user_id = ?";
$stmt_delete_order = $conn->prepare($sql_delete_order);
$stmt_delete_order->bind_param('ii', $order_id, $user_id);

if ($stmt_delete_order->execute()) {
    header('Location: my_order.php?status=cancel_success');
} else {
    header('Location: my_order.php?status=cancel_failed');
}

$stmt_check->close();
$stmt_delete_items->close();
$stmt_delete_order->close();
$conn->close();
?>
