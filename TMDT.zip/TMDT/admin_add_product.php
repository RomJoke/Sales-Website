<?php
include('K/connect.php');

// Xử lý khi biểu mẫu được gửi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title']; // Tên sản phẩm
    $price = $_POST['price'];
    $description = $_POST['description'];
    $status = $_POST['status']; // Trạng thái sản phẩm
    $category_name = $_POST['category']; // Tên danh mục từ biểu mẫu
    $image = $_FILES['image']['name']; // Tên tệp ảnh
    
    // Đường dẫn lưu ảnh
    $target_dir = "C:/xampp/htdocs/website/TMDT/images/";
    $target_file = $target_dir . basename($image);

    // Kiểm tra danh mục có tồn tại không
    $category_query = "SELECT id FROM category WHERE name = '$category_name'";
    $category_result = $conn->query($category_query);

    if ($category_result->num_rows > 0) {
        // Nếu danh mục đã tồn tại, lấy ID
        $category_row = $category_result->fetch_assoc();
        $catid = $category_row['id'];
    } else {
        // Nếu danh mục chưa tồn tại, thêm mới
        $insert_category_query = "INSERT INTO category (name, status) VALUES ('$category_name', 'Active')";
        if ($conn->query($insert_category_query)) {
            $catid = $conn->insert_id; // Lấy ID của danh mục vừa thêm
        } else {
            die("Error adding category: " . $conn->error);
        }
    }

    // Kiểm tra sản phẩm đã tồn tại trong danh mục chưa
    $product_check_query = "SELECT id FROM products WHERE title = '$title' AND catid = '$catid'";
    $product_check_result = $conn->query($product_check_query);

    if ($product_check_result->num_rows > 0) {
        // Sản phẩm đã tồn tại, thông báo cho admin
        echo "<div class='alert alert-warning'>Product already exists in this category.</div>";
    } else {
        // Nếu chưa tồn tại, tiến hành thêm sản phẩm
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            die("Failed to upload image.");
        }

        $sql = "INSERT INTO products (catid, title, price, description, image, date_added, status) 
                VALUES ('$catid', '$title', '$price', '$description', '$image', NOW(), '$status')";
        if ($conn->query($sql)) {
            header("Location: admin_dashboard.php?message=Product added successfully");
            exit;
        } else {
            die("Error adding product: " . $conn->error);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h1>Add New Product</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="category" class="form-label">Category Name</label>
                <input type="text" class="form-control" id="category" name="category" placeholder="Enter category name" required>
            </div>
            <div class="mb-3">
                <label for="title" class="form-label">Product Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price</label>
                <input type="number" step="0.01" class="form-control" id="price" name="price" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Product Image</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-control" id="status" name="status" required>
                    <option value="Available">Available</option>
                    <option value="Out of Stock">Out of Stock</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Add Product</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
