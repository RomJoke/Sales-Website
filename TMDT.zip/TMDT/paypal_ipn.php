<?php
require 'K/connect.php';

// Đọc phản hồi từ PayPal
$raw_post_data = file_get_contents('php://input');
$myPost = [];
foreach (explode('&', $raw_post_data) as $keyval) {
    list($key, $value) = explode('=', $keyval);
    $myPost[$key] = urldecode($value);
}

// Xác minh với PayPal
$req = 'cmd=_notify-validate&' . $raw_post_data;
$ch = curl_init('https://www.sandbox.paypal.com/cgi-bin/webscr');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
$res = curl_exec($ch);
curl_close($ch);

if (strcmp($res, "VERIFIED") === 0) {
    $order_id = $_POST['custom']; // custom chứa `order_id`
    $payment_status = $_POST['payment_status']; // Trạng thái thanh toán từ PayPal
    $txn_id = $_POST['txn_id']; // Transaction ID từ PayPal

    // Cập nhật trạng thái thanh toán
    $sql = "UPDATE orders SET payment_status = ?, paymentmode = ?, txn_id = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssi', $payment_status, $paymentmode, $txn_id, $order_id);

    $paymentmode = 'PayPal'; // Ghi nhận loại thanh toán
    $stmt->execute();
    $stmt->close();
}
$conn->close();
?>
