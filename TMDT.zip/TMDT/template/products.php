<?php 
include 'connect.php'; // Kết nối với cơ sở dữ liệu

if (isset($_GET['id'])) {
    $category_id = $_GET['id'];
    
    // Truy vấn để lấy sản phẩm thuộc danh mục này
    $sql_p = "SELECT * FROM products WHERE category_id = '$category_id'";
    $result_p = mysqli_query($conn, $sql_p);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sản phẩm</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Sản phẩm trong danh mục</h2>
        <div class="row">
            <?php if (mysqli_num_rows($result_p) > 0): ?>
                <?php while($products = mysqli_fetch_assoc($result_p)): ?>
                    <div class="col-sm-4">
                        <div class="thumbnail">
                            <img src="<?php echo htmlspecialchars($products['image']); ?>" alt="<?php echo htmlspecialchars($products['name']); ?>" style="width:100%">
                            <div class="caption">
                                <h3><?php echo htmlspecialchars($products['name']); ?></h3>
                                <p><?php echo htmlspecialchars($products['price']); ?></p> <!-- Nếu có mô tả -->
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>Không có sản phẩm nào trong danh mục này.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>

<?php
} else {
    echo "Không có danh mục nào được chọn.";
}
?>
