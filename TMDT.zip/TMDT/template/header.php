<!DOCTYPE html>
<html>
<head>
    <title>TMDT</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        .navbar-right .dropdown:hover .dropdown-menu {
            display: block; /* Hiển thị menu khi di chuột */
        }
        .navbar-right .dropdown-menu {
            min-width: 100px; /* Điều chỉnh độ rộng menu nếu cần */
        }
    </style>
</head>
<body>
<div class="container">
    <nav class="navbar navbar-default" style="margin-bottom: 0px;">
        <div class="container-fluid">
            <!-- Logo and brand name -->
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php" style="color:darkorange; font-size: 24px;">KAKA</a>
            </div>

            <!-- Navigation links on the right -->
            <ul class="nav navbar-nav navbar-right">
                
                <?php
                if (isset($_SESSION['user_id'])) {
                    // Hiển thị tên người dùng với menu thả xuống
                    $user_id = $_SESSION['user_id'];
                    $sql = "SELECT * FROM users WHERE id = $user_id";
                    $result = mysqli_query($conn, $sql);
                    $r = mysqli_fetch_assoc($result);
                    $username = htmlspecialchars($r['username']);
                ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle navbar-link" data-toggle="dropdown">
                            User: <?php echo $username; ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="edit_profile.php">Edit Profile</a></li>
                            <li><a href="logout.php">Đăng xuất</a></li>
                        </ul>
                    </li>
                <?php
                } else { // Nếu chưa đăng nhập, hiển thị Đăng Kí và Đăng nhập
                ?>
                    <li><a href="./register.php">Đăng Kí</a></li>
                    <li><a href="./login.php">Đăng nhập</a></li>
                <?php
                }
                ?>
            </ul>
        </div>
    </nav>
</div>
</body>
</html>
