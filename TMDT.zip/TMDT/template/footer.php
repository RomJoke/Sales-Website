<html> 
    <body> 
    <div class="contaner">
    <div class="jumbotron" style ="height: 150;padding-top: 10px; font-size: 20px; text-align: center">
        <h4> Contact </h4>
        <h5>Email: Khatopsv@gmail.com </h5>
         <h5>Phone: 0919597JQK</h5>
       <h5>Fax: 0919597JQK</h5>
     </div>
     </div>
    </body>
</html>
