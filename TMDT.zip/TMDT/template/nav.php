<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menu Dropdown</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <style>
    /* Kích hoạt menu ẩn khi hover */
    .navbar-nav .dropdown:hover .dropdown-menu {
      display: block;
    }

    /* Đảm bảo dropdown menu xuất hiện bên dưới */
    .dropdown-menu {
      margin-top: 0;
    }
    .navbar-inverse {
      background-color: #fff;
      border: none;
    }
    .navbar-inverse .navbar-nav > li > a {
      color: #000;
      font-size: 16px;
      padding: 15px 20px;
    }
    .navbar-inverse .navbar-nav > li > a:hover {
      background-color: #33CCFF;
    }
    .navbar-logo {
      height: 50px; /* Điều chỉnh chiều cao cho phù hợp */
      width: auto; /* Giữ tỷ lệ gốc của logo */
      margin-top: -10px; /* Căn chỉnh logo dọc cho vừa ý */
      padding: 5px; /* Thêm khoảng cách bên trong nếu cần */
    }

    /* Căn giữa logo trong thanh điều hướng */
    .navbar-header {
      display: flex;
      align-items: center;
     }

    /* Tạo thanh tìm kiếm */
    .search-box {
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 5px 10px;
      margin-right: 10px;
      display: flex;
      align-items: center;
    }
    .search-box input[type="text"] {
      border: none;
      outline: none;
      padding-left: 5px;
    }
    .icon {
      font-size: 18px;
      margin-left: 15px;
      color: #000;
    }
  </style>
</head>
<body>
  
<div class="container">
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <!-- Logo (bạn có thể thêm logo của mình ở đây nếu có) -->
        <a class="navbar-brand" href="#">Brand</a>
      </div>
      
      <ul class="nav navbar-nav">
        <!-- Menu My Account -->
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">My Account <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="my_order.php">My Orders</a></li>
            <li><a href="#">My Wishlist</a></li>
          </ul>
        </li>
        
        <!-- Menu Categories -->
        <li class="dropdown">
          <a class="dropdown-toggle" href="#">Categories <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <?php
              $sql_c = "SELECT * FROM category";
              $result_c = mysqli_query($conn, $sql_c);
              while($r_c = mysqli_fetch_assoc($result_c)) {
            ?>
              <li><a href="index.php?id=<?php echo $r_c['id']; ?>"><?php echo $r_c['name']; ?></a></li>
            <?php
              }
            ?>
          </ul>
        </li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <!-- Search box -->
        <li>
          <div class="search-box">
            <span class="glyphicon glyphicon-search"></span>
            <input type="text" placeholder="Search">
          </div>
        </li>
        <!-- Favorite and Cart icons -->
        <li><a href="#"><span class="glyphicon glyphicon-heart icon"></span></a></li>
        <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart icon"></span></a></li>
      </ul>
    </div>
  </nav>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
