<?php
session_start();
include('K/connect.php');

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Lấy dữ liệu từ bảng orders và các bảng liên quan
$sql = "
    SELECT 
        orders.id AS order_id,
        usersmeta.firstname,
        usersmeta.lastname,
        orders.timestamp,
        orders.payment_status,
        orders.totalprice,
        orders.paymentmode,
        orders.orderstatus,
        products.title AS product_name,
        orderitems.product_quantity,
        orderitems.product_price
    FROM 
        orders
    JOIN 
        usersmeta ON orders.user_id = usersmeta.user_id
    JOIN 
        orderitems ON orders.id = orderitems.order_id
    JOIN 
        products ON orderitems.product_id = products.id
";

$result = $conn->query($sql);

// Kiểm tra lỗi truy vấn
if (!$result) {
    die("Lỗi truy vấn: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #343a40;
            color: #fff;
            position: fixed;
            padding: 20px;
        }

        .sidebar a {
            text-decoration: none;
            color: #adb5bd;
            display: block;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .sidebar a:hover {
            background-color: #495057;
            color: #fff;
        }

        .content {
            margin-left: 260px;
            padding: 20px;
        }

        .table thead {
            background-color: #6c757d;
            color: #fff;
        }

        .btn-action {
            display: flex;
            gap: 10px;
        }
    </style>
</head>

<body>
    <?php if (isset($_GET['message'])): ?>
        <div class="alert alert-success">
            <?php echo htmlspecialchars($_GET['message']); ?>
        </div>
    <?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin</h2>
        <a href="#">Dashboard</a>
        <a href="#">Vendors</a>
        <a href="#">Customers</a>
        <a href="admin_add_product.php">Add New Product</a>
        <a href="#">Orders</a>
        <a href="#">Settings</a>
        <a href="#">Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h1>Order List</h1>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <input type="text" class="form-control w-25" placeholder="Search..." />
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Date</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Payment Status</th>
                    <th>Order Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td>#<?php echo $row['order_id']; ?></td>
                        <td><?php echo $row['firstname'] . ' ' . $row['lastname']; ?></td>
                        <td><?php echo date('M d, Y h:i A', strtotime($row['timestamp'])); ?></td>
                        <td><?php echo $row['product_name']; ?></td>
                        <td><?php echo $row['product_quantity']; ?></td>
                        <td>$<?php echo number_format($row['product_price'], 2); ?></td>
                        <td>$<?php echo number_format($row['product_quantity'] * $row['product_price'], 2); ?></td>
                        <td>
                            <span class="badge bg-<?php echo $row['payment_status'] === 'Paid' ? 'success' : 'warning'; ?>">
                                <?php echo $row['payment_status']; ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-<?php echo $row['orderstatus'] === 'Completed' ? 'primary' : 'info'; ?>">
                                <?php echo $row['orderstatus']; ?>
                            </span>
                        </td>
                        <td>
                            <a href="edit_order.php?id=<?php echo $row['order_id']; ?>" class="btn btn-success btn-sm">Edit</a>
                            <a href="delete_order.php?id=<?php echo $row['order_id']; ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure you want to delete this order?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
