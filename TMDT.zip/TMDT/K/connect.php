<?php 
// Thông tin kết nối
$servername = 'localhost';
$username = 'root';
$password = '';
$db_name = 'tmdt';

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $db_name);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Không thể kết nối đến CSDL: " . $conn->connect_error);
}

// Thiết lập mã hóa ký tự
if (!$conn->set_charset("utf8")) {
    die("Không thể thiết lập mã hóa ký tự: " . $conn->error);
}

// Thông báo kết nối thành công (tuỳ chọn)
// echo "Kết nối đến CSDL thành công!";
?>
